package com.aluno.projetoPro01;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class DirectTestRunner {
    public static void main(String[] args) {
        Class<?>[] testClasses = new Class<?>[] {
            GlobalExceptionHandlerTest.class,
            EntityAndServiceTest.class
        };

        int passed = 0;
        int failed = 0;
        List<String> failures = new ArrayList<>();

        for (Class<?> clazz : testClasses) {
            System.out.println("Running tests for: " + clazz.getSimpleName());
            for (Method method : clazz.getDeclaredMethods()) {
                if (method.isAnnotationPresent(Test.class)) {
                    try {
                        Object instance = clazz.getDeclaredConstructor().newInstance();
                        // run @BeforeEach
                        for (Method m : clazz.getDeclaredMethods()) {
                            if (m.isAnnotationPresent(BeforeEach.class)) {
                                m.setAccessible(true);
                                m.invoke(instance);
                            }
                        }
                        method.setAccessible(true);
                        method.invoke(instance);
                        System.out.println("  [PASS] " + method.getName());
                        passed++;
                    } catch (Throwable t) {
                        System.err.println("  [FAIL] " + method.getName() + ": " + t.getCause());
                        failures.add(clazz.getSimpleName() + "." + method.getName() + " -> " + t.getCause());
                        failed++;
                    }
                }
            }
        }

        System.out.println("\n=================================");
        System.out.println("TEST RESULTS: Passed: " + passed + ", Failed: " + failed);
        System.out.println("=================================");

        if (failed > 0) {
            System.err.println("Failures summary:");
            failures.forEach(System.err::println);
            System.exit(1);
        }
    }
}
