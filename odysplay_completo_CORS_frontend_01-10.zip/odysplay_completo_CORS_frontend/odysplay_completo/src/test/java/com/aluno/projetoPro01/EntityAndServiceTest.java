package com.aluno.projetoPro01;

import com.aluno.projetoPro01.dto.OrganizadoresDTO;
import com.aluno.projetoPro01.models.*;
import com.aluno.projetoPro01.repositories.UserRepository;
import com.aluno.projetoPro01.services.UserService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EntityAndServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @org.junit.jupiter.api.BeforeEach
    void init() {
        org.mockito.MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Lombok: Testar getters, setters, construtores e equals/hashCode em User")
    void testUserLombok() {
        User user = new User();
        user.setId(1L);
        user.setNome("João");
        user.setUsername("joao");
        user.setEmail("joao@email.com");
        user.setPassword("123456");
        user.setBiografia("Bio");

        assertEquals(1L, user.getId());
        assertEquals("João", user.getNome());
        assertEquals("joao", user.getUsername());
        assertEquals("joao@email.com", user.getEmail());
        assertEquals("123456", user.getPassword());
        assertEquals("Bio", user.getBiografia());

        User user2 = new User();
        user2.setId(1L);
        assertEquals(user, user2); // equals baseado no @EqualsAndHashCode.Include no ID
    }

    @Test
    @DisplayName("Lombok: Testar getters, setters e idUsuario customizado em Dev, Empresa, Game, Noticia, Comunidade")
    void testOtherEntitiesLombok() {
        Dev dev = new Dev();
        dev.setId(10L);
        dev.setIdUsuario(1L);
        dev.setEspecialidade("Unity");
        dev.setDataNascimento(LocalDate.of(1995, 5, 10));
        dev.setStatus("DISPONIVEL");
        assertEquals(10L, dev.getId());
        assertEquals(1L, dev.getIdUsuario());
        assertEquals("Unity", dev.getEspecialidade());

        Empresa emp = new Empresa();
        emp.setId(20L);
        emp.setIdUsuario(2L);
        emp.setNomeEmpresa("Odys Games");
        assertEquals(20L, emp.getId());
        assertEquals(2L, emp.getIdUsuario());
        assertEquals("Odys Games", emp.getNomeEmpresa());

        Game game = new Game();
        game.setId(30L);
        game.setIdDev(10L);
        game.setIdEmpresa(20L);
        game.setNomeGameJam("GameJam 2026");
        assertEquals(30L, game.getId());
        assertEquals(10L, game.getIdDev());
        assertEquals(20L, game.getIdEmpresa());

        Noticia noticia = new Noticia();
        noticia.setId(40L);
        noticia.setIdUsuario(1L);
        noticia.setTitulo("Noticia 1");
        assertEquals(40L, noticia.getId());
        assertEquals(1L, noticia.getIdUsuario());

        Comunidade com = new Comunidade();
        com.setId(50L);
        com.setIdUsuario(1L);
        com.setNome("Comunidade Indie");
        assertEquals(50L, com.getId());
        assertEquals(1L, com.getIdUsuario());

        OrganizadoresDTO dto = new OrganizadoresDTO(dev, emp);
        assertEquals(dev, dto.getDev());
        assertEquals(emp, dto.getEmpresa());
    }

    @Test
    @DisplayName("UserService: findById deve lançar EntityNotFoundException quando id não existir")
    void testUserServiceFindByIdThrowsEntityNotFoundException() {
        when(userRepository.findById(999L)).thenReturn(Optional.empty());

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> {
            userService.findById(999L);
        });

        assertEquals("Usuário não encontrado com ID: 999", ex.getMessage());
    }

    @Test
    @DisplayName("UserService: update deve lançar EntityNotFoundException quando id não existir")
    void testUserServiceUpdateThrowsEntityNotFoundException() {
        User user = new User();
        user.setId(999L);
        when(userRepository.findById(999L)).thenReturn(Optional.empty());

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> {
            userService.update(user);
        });

        assertEquals("Usuário não encontrado com ID: 999", ex.getMessage());
    }

    @Test
    @DisplayName("UserService: delete deve lançar EntityNotFoundException quando id não existir")
    void testUserServiceDeleteThrowsEntityNotFoundException() {
        when(userRepository.findById(999L)).thenReturn(Optional.empty());

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> {
            userService.delete(999L);
        });

        assertEquals("Usuário não encontrado com ID: 999", ex.getMessage());
    }
}
