package com.aluno.projetoPro01;

import com.aluno.projetoPro01.exceptions.ErrorResponse;
import com.aluno.projetoPro01.exceptions.GlobalExceptionHandler;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

public class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler exceptionHandler;

    @BeforeEach
    void setUp() {
        exceptionHandler = new GlobalExceptionHandler();
    }

    @Test
    @DisplayName("Deve retornar status 404 e ErrorResponse quando EntityNotFoundException for lançada")
    void shouldHandleEntityNotFoundException() {
        String msg = "Usuário não encontrado com ID: 9999";
        EntityNotFoundException ex = new EntityNotFoundException(msg);

        ResponseEntity<ErrorResponse> response = exceptionHandler.handleEntityNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(404, response.getBody().getStatus());
        assertEquals(msg, response.getBody().getMessage());
        assertNotNull(response.getBody().getTimestamp());
    }

    @Test
    @DisplayName("Deve retornar status 500 e ErrorResponse quando Exception genérica for lançada")
    void shouldHandleGenericException() {
        String msg = "Falha no servidor";
        Exception ex = new RuntimeException(msg);

        ResponseEntity<ErrorResponse> response = exceptionHandler.handleGenericException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(500, response.getBody().getStatus());
        assertTrue(response.getBody().getMessage().contains(msg));
        assertNotNull(response.getBody().getTimestamp());
    }
}
