package com.aluno.projetoPro01.services;

import com.aluno.projetoPro01.models.Empresa;
import com.aluno.projetoPro01.models.Game;
import com.aluno.projetoPro01.models.User;
import com.aluno.projetoPro01.repositories.EmpresaRepository;
import com.aluno.projetoPro01.repositories.GameRepository;
import com.aluno.projetoPro01.repositories.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmpresaService {

    @Autowired
    private EmpresaRepository empresaRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GameRepository gameRepository;

    public Empresa findById(Long id) {
        return this.empresaRepository.findById(id).orElseThrow(() ->
                new EntityNotFoundException("Empresa não encontrada com ID: " + id));
    }

    public List<Empresa> findAll() {
        return this.empresaRepository.findAll();
    }

    @Transactional
    public Empresa create(Empresa obj) {
        obj.setId(null);
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            obj.setUser(user);
        }
        if (obj.getCnpj() == null || obj.getCnpj().trim().isEmpty()) {
            long uid = obj.getIdUsuario() != null ? obj.getIdUsuario() : System.currentTimeMillis() % 1000;
            obj.setCnpj(String.format("%02d.345.678/0001-%02d", uid % 100, (uid + 10) % 100));
        }
        if (obj.getSetor() == null || obj.getSetor().trim().isEmpty()) {
            obj.setSetor("Desenvolvimento de Jogos");
        }
        return this.empresaRepository.save(obj);
    }

    @Transactional
    public Empresa update(Empresa obj) {
        if (obj.getId() == null) {
            throw new EntityNotFoundException("ID da empresa não fornecido para atualização.");
        }
        Empresa existing = findById(obj.getId());
        if (obj.getNomeEmpresa() != null) {
            existing.setNomeEmpresa(obj.getNomeEmpresa());
        }
        if (obj.getDescricao() != null) {
            existing.setDescricao(obj.getDescricao());
        }
        if (obj.getCnpj() != null) {
            existing.setCnpj(obj.getCnpj());
        }
        if (obj.getWebsiteUrl() != null) {
            existing.setWebsiteUrl(obj.getWebsiteUrl());
        }
        if (obj.getSetor() != null) {
            existing.setSetor(obj.getSetor());
        }
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            existing.setUser(user);
        }
        return this.empresaRepository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        Empresa empresa = findById(id);
        this.empresaRepository.delete(empresa);
    }

    public List<Game> findGamesByEmpresaId(Long empresaId) {
        findById(empresaId);
        return this.gameRepository.findByEmpresaId(empresaId);
    }
}
