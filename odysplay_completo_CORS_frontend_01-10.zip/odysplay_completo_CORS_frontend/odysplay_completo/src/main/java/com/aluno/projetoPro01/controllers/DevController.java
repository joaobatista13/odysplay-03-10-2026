package com.aluno.projetoPro01.controllers;

import com.aluno.projetoPro01.models.Dev;
import com.aluno.projetoPro01.models.Game;
import com.aluno.projetoPro01.services.DevService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping({"/dev", "/devs"})
public class DevController {

    @Autowired
    private DevService devService;

    @GetMapping("/{id}")
    public ResponseEntity<Dev> findById(@PathVariable Long id) {
        Dev obj = this.devService.findById(id);
        return ResponseEntity.ok().body(obj);
    }

    @GetMapping
    public ResponseEntity<List<Dev>> findAll() {
        List<Dev> list = this.devService.findAll();
        return ResponseEntity.ok().body(list);
    }

    @PostMapping
    public ResponseEntity<Dev> create(@Validated(Dev.CreateDev.class) @RequestBody Dev obj) {
        Dev created = this.devService.create(obj);
        URI uri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/dev/{id}").buildAndExpand(created.getId()).toUri();
        return ResponseEntity.created(uri).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody Dev obj, @PathVariable Long id) {
        obj.setId(id);
        this.devService.update(obj);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.devService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/games")
    public ResponseEntity<List<Game>> findGamesByDevId(@PathVariable Long id) {
        List<Game> list = this.devService.findGamesByDevId(id);
        return ResponseEntity.ok().body(list);
    }
}
