package com.aluno.projetoPro01.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Entity
@Table(name = "game")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Game {

    public interface CreateGame {}
    public interface UpdateGame {}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "idDev", nullable = true)
    @JsonIgnoreProperties({"games", "user"})
    private Dev dev;

    @ManyToOne
    @JoinColumn(name = "idEmpresa", nullable = true)
    @JsonIgnoreProperties({"games", "user"})
    private Empresa empresa;

    @Column(name = "nomeGameJam", length = 100, nullable = false)
    @NotNull(groups = CreateGame.class)
    private String nomeGameJam;

    @Column(name = "tema", length = 100, nullable = false)
    @NotNull(groups = CreateGame.class)
    private String tema;

    @Column(name = "regras", columnDefinition = "TEXT", nullable = false)
    @NotNull(groups = CreateGame.class)
    private String regras;

    @Column(name = "descricaoGameJam", columnDefinition = "TEXT", nullable = false)
    @NotNull(groups = CreateGame.class)
    private String descricaoGameJam;

    @Column(name = "premios", length = 255)
    private String premios;

    @JsonProperty("idDev")
    public Long getIdDev() {
        return dev != null ? dev.getId() : null;
    }

    @JsonProperty("idDev")
    public void setIdDev(Long idDev) {
        if (idDev != null) {
            this.dev = new Dev();
            this.dev.setId(idDev);
        } else {
            this.dev = null;
        }
    }

    @JsonProperty("idEmpresa")
    public Long getIdEmpresa() {
        return empresa != null ? empresa.getId() : null;
    }

    @JsonProperty("idEmpresa")
    public void setIdEmpresa(Long idEmpresa) {
        if (idEmpresa != null) {
            this.empresa = new Empresa();
            this.empresa.setId(idEmpresa);
        } else {
            this.empresa = null;
        }
    }
}
