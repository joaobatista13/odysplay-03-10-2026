package com.aluno.projetoPro01.controllers;

import com.aluno.projetoPro01.models.Noticia;
import com.aluno.projetoPro01.services.NoticiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping({"/noticia", "/noticias"})
public class NoticiaController {

    @Autowired
    private NoticiaService noticiaService;

    @GetMapping("/{id}")
    public ResponseEntity<Noticia> findById(@PathVariable Long id) {
        Noticia obj = this.noticiaService.findById(id);
        return ResponseEntity.ok().body(obj);
    }

    @GetMapping
    public ResponseEntity<List<Noticia>> findAll() {
        List<Noticia> list = this.noticiaService.findAll();
        return ResponseEntity.ok().body(list);
    }

    @PostMapping
    public ResponseEntity<Noticia> create(@Validated(Noticia.CreateNoticia.class) @RequestBody Noticia obj) {
        Noticia created = this.noticiaService.create(obj);
        URI uri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/noticia/{id}").buildAndExpand(created.getId()).toUri();
        return ResponseEntity.created(uri).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody Noticia obj, @PathVariable Long id) {
        obj.setId(id);
        this.noticiaService.update(obj);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.noticiaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
