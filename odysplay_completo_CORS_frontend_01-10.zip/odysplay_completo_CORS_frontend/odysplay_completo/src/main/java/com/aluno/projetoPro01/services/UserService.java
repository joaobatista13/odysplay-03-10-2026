package com.aluno.projetoPro01.services;

import com.aluno.projetoPro01.models.Comunidade;
import com.aluno.projetoPro01.models.Noticia;
import com.aluno.projetoPro01.models.User;
import com.aluno.projetoPro01.repositories.ComunidadeRepository;
import com.aluno.projetoPro01.repositories.NoticiaRepository;
import com.aluno.projetoPro01.repositories.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NoticiaRepository noticiaRepository;

    @Autowired
    private ComunidadeRepository comunidadeRepository;

    public User findById(Long id) {
        return this.userRepository.findById(id).orElseThrow(() ->
                new EntityNotFoundException("Usuário não encontrado com ID: " + id));
    }

    public List<User> findAll() {
        return this.userRepository.findAll();
    }

    @Transactional
    public User create(User obj) {
        obj.setId(null);
        return this.userRepository.save(obj);
    }

    @Transactional
    public User update(User obj) {
        if (obj.getId() == null) {
            throw new EntityNotFoundException("ID do usuário não fornecido para atualização.");
        }
        User existing = findById(obj.getId());
        if (obj.getNome() != null) {
            existing.setNome(obj.getNome());
        }
        if (obj.getUsername() != null) {
            existing.setUsername(obj.getUsername());
        }
        if (obj.getEmail() != null) {
            existing.setEmail(obj.getEmail());
        }
        if (obj.getPassword() != null) {
            existing.setPassword(obj.getPassword());
        }
        if (obj.getBiografia() != null) {
            existing.setBiografia(obj.getBiografia());
        }
        return this.userRepository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        User user = findById(id);
        this.userRepository.delete(user);
    }

    public List<Noticia> findNoticiasByUserId(Long id) {
        findById(id);
        return this.noticiaRepository.findByUserId(id);
    }

    public List<Comunidade> findComunidadesByUserId(Long id) {
        findById(id);
        return this.comunidadeRepository.findByUserId(id);
    }
}
