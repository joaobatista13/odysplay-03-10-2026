const API_URL = "http://localhost:8080/games";

const form = document.getElementById("gameForm");
const tabelaGames = document.getElementById("tabelaGames");
const mensagem = document.getElementById("mensagem");

document.addEventListener("DOMContentLoaded", carregarGames);

form.addEventListener("submit", salvarGame);

async function carregarGames() {
    try {
        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Não foi possível carregar os Game Jams.");
        }

        const games = await response.json();
        renderizarGames(games);

    } catch (error) {
        tabelaGames.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-danger">
                    ${escapeHtml(error.message)}
                </td>
            </tr>
        `;

        mostrarMensagem(error.message, "danger");
    }
}

function renderizarGames(games) {
    tabelaGames.innerHTML = "";

    if (!games || games.length === 0) {
        tabelaGames.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted">
                    Nenhuma Game Jam cadastrada.
                </td>
            </tr>
        `;
        return;
    }

    games.forEach(game => {
        const linha = document.createElement("tr");

        linha.innerHTML = `
            <td>${game.id ?? ""}</td>
            <td>${escapeHtml(game.nomeGameJam)}</td>
            <td>${escapeHtml(game.tema)}</td>
            <td>${escapeHtml(game.descricaoGameJam)}</td>
            <td>${escapeHtml(game.premios || "-")}</td>
            <td class="text-nowrap">
                <button class="btn btn-warning btn-sm me-1"
                        onclick="editarGame(${game.id})">
                    Editar
                </button>

                <button class="btn btn-danger btn-sm"
                        onclick="excluirGame(${game.id})">
                    Excluir
                </button>
            </td>
        `;

        tabelaGames.appendChild(linha);
    });
}

async function salvarGame(event) {
    event.preventDefault();

    const id = document.getElementById("id").value;

    const game = {
        nomeGameJam: document.getElementById("nomeGameJam").value.trim(),
        tema: document.getElementById("tema").value.trim(),
        regras: document.getElementById("regras").value.trim(),
        descricaoGameJam: document.getElementById("descricaoGameJam").value.trim(),
        premios: document.getElementById("premios").value.trim()
    };

    const idDev = document.getElementById("idDev").value;
    const idEmpresa = document.getElementById("idEmpresa").value;

    if (idDev) {
        game.idDev = Number(idDev);
    }

    if (idEmpresa) {
        game.idEmpresa = Number(idEmpresa);
    }

    try {
        const response = await fetch(
            id ? `${API_URL}/${id}` : API_URL,
            {
                method: id ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(game)
            }
        );

        if (!response.ok) {
            const texto = await response.text();
            throw new Error(
                texto || `Erro ao ${id ? "atualizar" : "cadastrar"} a Game Jam.`
            );
        }

        mostrarMensagem(
            id ? "Game Jam atualizada com sucesso!" : "Game Jam cadastrada com sucesso!",
            "success"
        );

        limparFormulario();
        await carregarGames();

    } catch (error) {
        mostrarMensagem(error.message, "danger");
    }
}

async function editarGame(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`);

        if (!response.ok) {
            throw new Error("Não foi possível buscar a Game Jam.");
        }

        const game = await response.json();

        document.getElementById("id").value = game.id ?? "";
        document.getElementById("nomeGameJam").value = game.nomeGameJam ?? "";
        document.getElementById("tema").value = game.tema ?? "";
        document.getElementById("regras").value = game.regras ?? "";
        document.getElementById("descricaoGameJam").value = game.descricaoGameJam ?? "";
        document.getElementById("premios").value = game.premios ?? "";
        document.getElementById("idDev").value = game.idDev ?? "";
        document.getElementById("idEmpresa").value = game.idEmpresa ?? "";

        document.getElementById("tituloFormulario").textContent = "Editar Game Jam";
        document.getElementById("btnSalvar").textContent = "Atualizar";
        document.getElementById("btnCancelar").classList.remove("d-none");

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    } catch (error) {
        mostrarMensagem(error.message, "danger");
    }
}

async function excluirGame(id) {
    if (!confirm(`Deseja realmente excluir a Game Jam ${id}?`)) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: "DELETE"
        });

        if (!response.ok) {
            const texto = await response.text();
            throw new Error(texto || "Não foi possível excluir a Game Jam.");
        }

        mostrarMensagem("Game Jam excluída com sucesso!", "success");
        await carregarGames();

    } catch (error) {
        mostrarMensagem(error.message, "danger");
    }
}

function cancelarEdicao() {
    limparFormulario();
}

function limparFormulario() {
    form.reset();

    document.getElementById("id").value = "";
    document.getElementById("tituloFormulario").textContent = "Cadastrar Game Jam";
    document.getElementById("btnSalvar").textContent = "Salvar";
    document.getElementById("btnCancelar").classList.add("d-none");
}

function mostrarMensagem(texto, tipo) {
    mensagem.textContent = texto;
    mensagem.className = `alert alert-${tipo}`;

    setTimeout(() => {
        mensagem.classList.add("d-none");
    }, 4000);
}

function escapeHtml(valor) {
    if (valor === null || valor === undefined) {
        return "";
    }

    return String(valor)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
