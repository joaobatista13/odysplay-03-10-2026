# Upgrade Plan: projetoPro01 (20260820035352)

- **Generated**: 2026-08-20
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21.0.12.1: C:\Program Files\Java\jdk-21.0.12.1\bin (current project JDK; baseline)
- JDK 25: **<TO_BE_INSTALLED>** (required by upgrade and final validation)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (required; no Maven installation detected)
- Version control: unavailable; changes remain uncommitted in the working directory.

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (version control unavailable)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime/compiler target 25 (latest LTS)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested latest LTS runtime |
| Spring Boot | 3.3.2 | 3.3.2 | No framework upgrade requested; retain unless Java 25 compilation exposes a compatibility blocker |
| Maven | Not installed | 3.9+ | Required to build and test the Maven project |
| maven-compiler-plugin | Spring Boot 3.3.2 managed | 3.11+ recommended | Java 25 compilation support is delegated to javac; update only if the managed plugin cannot compile |
| Lombok | Spring Boot 3.3.2 managed | Current managed version or newer | Annotation processing may require a newer release for Java 25; verify during compilation |
| MySQL Connector/J | Spring Boot 3.3.2 managed | Current managed version | Runtime database driver; no direct Java 25 incompatibility found |

## Derived Upgrades

- Install JDK 25 because it is the requested runtime target and is not available locally.
- Install Maven 3.9.x because no Maven executable or wrapper is present.
- Set `java.version` to 25 in `pom.xml` so Maven compiler configuration and Spring Boot packaging target Java 25.
- Keep Spring Boot 3.3.2 and application dependencies unchanged unless the target-JDK build identifies a concrete compatibility failure; this avoids an unrelated framework migration.
- Run dependency CVE validation after the upgrade and apply only necessary patched versions.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| `pom.xml` | `java.version` | 21 | upgrade | 25 | Sets the compiler/runtime target requested by the user |
| `pom.xml` | Spring Boot parent | 3.3.2 | retain | 3.3.2 | No evidence from local scan requires a framework upgrade; verify on JDK 25 |
| `pom.xml` | Maven compiler/plugin dependencies | Spring Boot managed | retain or upgrade | Compatible with Java 25 | Change only if `test-compile` proves the managed versions cannot compile |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| `src/main/java/**` | Full source scan | No internal JDK APIs or removed APIs found | No source change expected | Local compatibility scan found no Java 25 migration pattern |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| `src/main/resources/application.properties` | Spring datasource/JPA settings | Existing MySQL/JPA settings | No change expected | No Java-version-specific configuration found |

### CI/CD Changes

No CI/CD files are present in the workspace, so no pipeline or container runtime changes are required.

### Risks & Warnings

- **Build-tool availability**: Maven is absent and must be installed before baseline and upgrade verification. **Mitigation**: install Maven 3.9.x and use it consistently for all checks.
- **Java 25 annotation processing**: Lombok or other managed annotation processors may require a patched version. **Mitigation**: run `mvn clean test-compile`; upgrade only the failing processor/dependency and repeat the check.
- **Spring Boot 3.3.2 on Java 25**: Java 25 is newer than the framework line's original release window. **Mitigation**: preserve the current framework first; if a reproducible compatibility error occurs, apply the smallest compatible plugin/dependency update and document it.
- **Runtime database configuration**: full application tests may require a local MySQL instance. **Mitigation**: distinguish infrastructure startup failures from code failures, while still attempting all tests and fixing application-caused failures.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install the requested JDK and required Maven build tool before any verification.
  - **Changes to Make**: Install JDK 25 and Maven 3.9.x; verify executable paths.
  - **Verification**: List installed JDKs and Maven; expected JDK 25 and Maven 3.9.x available.

- Step 2: Setup Baseline
  - **Rationale**: Capture the pre-upgrade compilation and test result using the current JDK 21.
  - **Changes to Make**: None.
  - **Verification**: `mvn clean compile test-compile -q` and `mvn clean test -q` with JDK 21; record pass rate.

- Step 3: Upgrade Java Target
  - **Rationale**: Apply the requested Java 25 target and resolve only concrete compilation issues caused by the target.
  - **Changes to Make**: Apply Dependency Changes and any directly required annotation-processor/plugin compatibility fixes from the Impact Analysis.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; main and test compilation must succeed.

- Step 4: CVE Validation and Fix
  - **Rationale**: Validate the final direct dependency set and remediate reported vulnerabilities without unrelated upgrades.
  - **Changes to Make**: Scan resolved direct dependencies; update vulnerable direct/BOM-managed versions when patches exist.
  - **Verification**: `mvn clean test-compile -q`, then repeat CVE scan; expected no actionable CVEs.

- Step 5: Final Validation
  - **Rationale**: Confirm the target Java version and complete test pass rate after all changes.
  - **Changes to Make**: Resolve all remaining upgrade-related failures and remove temporary workarounds.
  - **Verification**: `mvn clean test-compile -q`, `mvn clean test -q`, and `mvn clean verify -Djacoco.skip=false` with JDK 25; expected compilation success and 100% tests passing.
