package com.aluno.projetoPro01.repositories;

import com.aluno.projetoPro01.models.Noticia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NoticiaRepository extends JpaRepository<Noticia, Long> {
    List<Noticia> findByUserId(Long userId);
    List<Noticia> findByUser_Id(Long userId);
}
