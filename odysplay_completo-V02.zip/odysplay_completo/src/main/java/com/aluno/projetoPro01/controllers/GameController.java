package com.aluno.projetoPro01.controllers;

import com.aluno.projetoPro01.dto.OrganizadoresDTO;
import com.aluno.projetoPro01.models.Game;
import com.aluno.projetoPro01.services.GameService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping({"/game", "/games"})
public class GameController {

    @Autowired
    private GameService gameService;

    @GetMapping("/{id}")
    public ResponseEntity<Game> findById(@PathVariable Long id) {
        Game obj = this.gameService.findById(id);
        return ResponseEntity.ok().body(obj);
    }

    @GetMapping
    public ResponseEntity<List<Game>> findAll() {
        List<Game> list = this.gameService.findAll();
        return ResponseEntity.ok().body(list);
    }

    @PostMapping
    public ResponseEntity<Game> create(@Valid @RequestBody Game obj) {
        Game created = this.gameService.create(obj);
        URI uri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/game/{id}").buildAndExpand(created.getId()).toUri();
        return ResponseEntity.created(uri).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody Game obj, @PathVariable Long id) {
        obj.setId(id);
        this.gameService.update(obj);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.gameService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/organizadores")
    public ResponseEntity<OrganizadoresDTO> findOrganizadores(@PathVariable Long id) {
        OrganizadoresDTO dto = this.gameService.findOrganizadores(id);
        return ResponseEntity.ok().body(dto);
    }
}
