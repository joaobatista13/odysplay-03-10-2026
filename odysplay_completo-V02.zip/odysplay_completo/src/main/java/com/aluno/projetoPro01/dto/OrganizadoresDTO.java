package com.aluno.projetoPro01.dto;

import com.aluno.projetoPro01.models.Dev;
import com.aluno.projetoPro01.models.Empresa;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrganizadoresDTO {
    private Dev dev;
    private Empresa empresa;
}
