package com.aluno.projetoPro01.services;

import com.aluno.projetoPro01.dto.OrganizadoresDTO;
import com.aluno.projetoPro01.models.Dev;
import com.aluno.projetoPro01.models.Empresa;
import com.aluno.projetoPro01.models.Game;
import com.aluno.projetoPro01.repositories.DevRepository;
import com.aluno.projetoPro01.repositories.EmpresaRepository;
import com.aluno.projetoPro01.repositories.GameRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class GameService {

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private DevRepository devRepository;

    @Autowired
    private EmpresaRepository empresaRepository;

    public Game findById(Long id) {
        return this.gameRepository.findById(id).orElseThrow(() ->
                new EntityNotFoundException("Game Jam não encontrada com ID: " + id));
    }

    public List<Game> findAll() {
        return this.gameRepository.findAll();
    }

    @Transactional
    public Game create(Game obj) {
        obj.setId(null);
        if (obj.getIdDev() != null) {
            Dev dev = this.devRepository.findById(obj.getIdDev()).orElseThrow(() ->
                    new EntityNotFoundException("Desenvolvedor não encontrado com ID: " + obj.getIdDev()));
            obj.setDev(dev);
        }
        if (obj.getIdEmpresa() != null) {
            Empresa empresa = this.empresaRepository.findById(obj.getIdEmpresa()).orElseThrow(() ->
                    new EntityNotFoundException("Empresa não encontrada com ID: " + obj.getIdEmpresa()));
            obj.setEmpresa(empresa);
        }
        return this.gameRepository.save(obj);
    }

    @Transactional
    public Game update(Game obj) {
        if (obj.getId() == null) {
            throw new EntityNotFoundException("Game Jam não encontrada: ID não fornecido");
        }
        Game existing = findById(obj.getId());
        if (obj.getNomeGameJam() != null) {
            existing.setNomeGameJam(obj.getNomeGameJam());
        }
        if (obj.getTema() != null) {
            existing.setTema(obj.getTema());
        }
        if (obj.getRegras() != null) {
            existing.setRegras(obj.getRegras());
        }
        if (obj.getDescricaoGameJam() != null) {
            existing.setDescricaoGameJam(obj.getDescricaoGameJam());
        }
        if (obj.getPremios() != null) {
            existing.setPremios(obj.getPremios());
        }
        if (obj.getIdDev() != null) {
            Dev dev = this.devRepository.findById(obj.getIdDev()).orElseThrow(() ->
                    new EntityNotFoundException("Desenvolvedor não encontrado com ID: " + obj.getIdDev()));
            existing.setDev(dev);
        }
        if (obj.getIdEmpresa() != null) {
            Empresa empresa = this.empresaRepository.findById(obj.getIdEmpresa()).orElseThrow(() ->
                    new EntityNotFoundException("Empresa não encontrada com ID: " + obj.getIdEmpresa()));
            existing.setEmpresa(empresa);
        }
        return this.gameRepository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        Game game = findById(id);
        this.gameRepository.delete(game);
    }

    public OrganizadoresDTO findOrganizadores(Long gameId) {
        Game game = findById(gameId);
        return new OrganizadoresDTO(game.getDev(), game.getEmpresa());
    }
}
