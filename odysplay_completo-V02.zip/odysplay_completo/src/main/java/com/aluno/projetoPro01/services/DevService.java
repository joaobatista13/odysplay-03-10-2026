package com.aluno.projetoPro01.services;

import com.aluno.projetoPro01.models.Dev;
import com.aluno.projetoPro01.models.Game;
import com.aluno.projetoPro01.models.User;
import com.aluno.projetoPro01.repositories.DevRepository;
import com.aluno.projetoPro01.repositories.GameRepository;
import com.aluno.projetoPro01.repositories.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class DevService {

    @Autowired
    private DevRepository devRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GameRepository gameRepository;

    public Dev findById(Long id) {
        return this.devRepository.findById(id).orElseThrow(() ->
                new EntityNotFoundException("Desenvolvedor não encontrado com ID: " + id));
    }

    public List<Dev> findAll() {
        return this.devRepository.findAll();
    }

    @Transactional
    public Dev create(Dev obj) {
        obj.setId(null);
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            obj.setUser(user);
        }
        if (obj.getStatus() == null || obj.getStatus().trim().isEmpty()) {
            obj.setStatus("DISPONIVEL");
        }
        if (obj.getDataNascimento() == null) {
            obj.setDataNascimento(LocalDate.of(2000, 1, 1));
        }
        return this.devRepository.save(obj);
    }

    @Transactional
    public Dev update(Dev obj) {
        if (obj.getId() == null) {
            throw new EntityNotFoundException("Desenvolvedor não encontrado: ID não fornecido");
        }
        Dev existing = findById(obj.getId());
        if (obj.getEspecialidade() != null) {
            existing.setEspecialidade(obj.getEspecialidade());
        }
        if (obj.getDataNascimento() != null) {
            existing.setDataNascimento(obj.getDataNascimento());
        }
        if (obj.getStatus() != null) {
            existing.setStatus(obj.getStatus());
        }
        if (obj.getGithubUrl() != null) {
            existing.setGithubUrl(obj.getGithubUrl());
        }
        if (obj.getBiografia() != null) {
            existing.setBiografia(obj.getBiografia());
        }
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            existing.setUser(user);
        }
        return this.devRepository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        Dev dev = findById(id);
        this.devRepository.delete(dev);
    }

    public List<Game> findGamesByDevId(Long devId) {
        findById(devId);
        return this.gameRepository.findByDevId(devId);
    }
}
