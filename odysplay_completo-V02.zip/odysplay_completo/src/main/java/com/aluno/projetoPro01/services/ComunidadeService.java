package com.aluno.projetoPro01.services;

import com.aluno.projetoPro01.models.Comunidade;
import com.aluno.projetoPro01.models.User;
import com.aluno.projetoPro01.repositories.ComunidadeRepository;
import com.aluno.projetoPro01.repositories.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ComunidadeService {

    @Autowired
    private ComunidadeRepository comunidadeRepository;

    @Autowired
    private UserRepository userRepository;

    public Comunidade findById(Long id) {
        return this.comunidadeRepository.findById(id).orElseThrow(() ->
                new EntityNotFoundException("Comunidade não encontrada com ID: " + id));
    }

    public List<Comunidade> findAll() {
        return this.comunidadeRepository.findAll();
    }

    @Transactional
    public Comunidade create(Comunidade obj) {
        obj.setId(null);
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            obj.setUser(user);
        }
        if (obj.getDataCriacao() == null) {
            obj.setDataCriacao(LocalDateTime.now());
        }
        return this.comunidadeRepository.save(obj);
    }

    @Transactional
    public Comunidade update(Comunidade obj) {
        if (obj.getId() == null) {
            throw new EntityNotFoundException("Comunidade não encontrada: ID não fornecido");
        }
        Comunidade existing = findById(obj.getId());
        if (obj.getNome() != null) {
            existing.setNome(obj.getNome());
        }
        if (obj.getRegras() != null) {
            existing.setRegras(obj.getRegras());
        }
        if (obj.getDescricao() != null) {
            existing.setDescricao(obj.getDescricao());
        }
        if (obj.getDataCriacao() != null) {
            existing.setDataCriacao(obj.getDataCriacao());
        }
        if (obj.getTopicoPrincipal() != null) {
            existing.setTopicoPrincipal(obj.getTopicoPrincipal());
        }
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            existing.setUser(user);
        }
        return this.comunidadeRepository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        Comunidade comunidade = findById(id);
        this.comunidadeRepository.delete(comunidade);
    }
}
