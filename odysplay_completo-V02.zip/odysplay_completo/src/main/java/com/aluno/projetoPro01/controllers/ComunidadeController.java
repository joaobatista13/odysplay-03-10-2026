package com.aluno.projetoPro01.controllers;

import com.aluno.projetoPro01.models.Comunidade;
import com.aluno.projetoPro01.services.ComunidadeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping({"/comunidade", "/comunidades"})
public class ComunidadeController {

    @Autowired
    private ComunidadeService comunidadeService;

    @GetMapping("/{id}")
    public ResponseEntity<Comunidade> findById(@PathVariable Long id) {
        Comunidade obj = this.comunidadeService.findById(id);
        return ResponseEntity.ok().body(obj);
    }

    @GetMapping
    public ResponseEntity<List<Comunidade>> findAll() {
        List<Comunidade> list = this.comunidadeService.findAll();
        return ResponseEntity.ok().body(list);
    }

    @PostMapping
    public ResponseEntity<Comunidade> create(@Valid @RequestBody Comunidade obj) {
        Comunidade created = this.comunidadeService.create(obj);
        URI uri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/comunidade/{id}").buildAndExpand(created.getId()).toUri();
        return ResponseEntity.created(uri).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody Comunidade obj, @PathVariable Long id) {
        obj.setId(id);
        this.comunidadeService.update(obj);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.comunidadeService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
