package com.aluno.projetoPro01.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "comunidade")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Comunidade {

    public interface CreateComunidade {}
    public interface UpdateComunidade {}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "idUsuario", nullable = false)
    @JsonIgnoreProperties({"dev", "empresa", "noticias", "comunidades", "password"})
    private User user;

    @Column(name = "nome", length = 100, nullable = false, unique = true)
    @NotBlank(message = "O campo 'nome' é obrigatório")
    private String nome;

    @Column(name = "regras", columnDefinition = "TEXT")
    private String regras;

    @Column(name = "descricao", length = 255, nullable = false)
    @NotBlank(message = "O campo 'descricao' é obrigatório")
    private String descricao;

    @Column(name = "dataCriacao", nullable = false)
    private LocalDateTime dataCriacao;

    @Column(name = "topicoPrincipal", length = 50, nullable = false)
    @NotBlank(message = "O campo 'topicoPrincipal' é obrigatório")
    private String topicoPrincipal;

    @JsonProperty("idUsuario")
    public Long getIdUsuario() {
        return user != null ? user.getId() : null;
    }

    @JsonProperty("idUsuario")
    public void setIdUsuario(Long idUsuario) {
        if (idUsuario != null) {
            this.user = new User();
            this.user.setId(idUsuario);
        }
    }
}
