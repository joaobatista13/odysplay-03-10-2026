package com.aluno.projetoPro01.repositories;

import com.aluno.projetoPro01.models.Game;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GameRepository extends JpaRepository<Game, Long> {
    List<Game> findByDevId(Long devId);
    List<Game> findByDev_Id(Long devId);
    List<Game> findByEmpresaId(Long empresaId);
    List<Game> findByEmpresa_Id(Long empresaId);
}
