package com.aluno.projetoPro01.repositories;

import com.aluno.projetoPro01.models.Comunidade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ComunidadeRepository extends JpaRepository<Comunidade, Long> {
    List<Comunidade> findByUserId(Long userId);
    List<Comunidade> findByUser_Id(Long userId);
    Optional<Comunidade> findByNome(String nome);
}
