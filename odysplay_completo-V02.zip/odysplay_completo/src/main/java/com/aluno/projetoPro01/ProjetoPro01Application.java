package com.aluno.projetoPro01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoPro01Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoPro01Application.class, args);
	}

}

