package com.aluno.projetoPro01.controllers;

import com.aluno.projetoPro01.models.Empresa;
import com.aluno.projetoPro01.models.Game;
import com.aluno.projetoPro01.services.EmpresaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping({"/empresa", "/empresas"})
public class EmpresaController {

    @Autowired
    private EmpresaService empresaService;

    @GetMapping("/{id}")
    public ResponseEntity<Empresa> findById(@PathVariable Long id) {
        Empresa obj = this.empresaService.findById(id);
        return ResponseEntity.ok().body(obj);
    }

    @GetMapping
    public ResponseEntity<List<Empresa>> findAll() {
        List<Empresa> list = this.empresaService.findAll();
        return ResponseEntity.ok().body(list);
    }

    @PostMapping
    public ResponseEntity<Empresa> create(@Valid @RequestBody Empresa obj) {
        Empresa created = this.empresaService.create(obj);
        URI uri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/empresa/{id}").buildAndExpand(created.getId()).toUri();
        return ResponseEntity.created(uri).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody Empresa obj, @PathVariable Long id) {
        obj.setId(id);
        this.empresaService.update(obj);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.empresaService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/games")
    public ResponseEntity<List<Game>> findGamesByEmpresaId(@PathVariable Long id) {
        List<Game> list = this.empresaService.findGamesByEmpresaId(id);
        return ResponseEntity.ok().body(list);
    }
}
