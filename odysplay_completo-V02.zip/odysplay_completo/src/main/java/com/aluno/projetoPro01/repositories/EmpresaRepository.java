package com.aluno.projetoPro01.repositories;

import com.aluno.projetoPro01.models.Empresa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmpresaRepository extends JpaRepository<Empresa, Long> {
    Optional<Empresa> findByUserId(Long userId);
    Optional<Empresa> findByUser_Id(Long userId);
    Optional<Empresa> findByCnpj(String cnpj);
}
