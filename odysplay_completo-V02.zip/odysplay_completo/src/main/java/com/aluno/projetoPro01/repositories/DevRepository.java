package com.aluno.projetoPro01.repositories;

import com.aluno.projetoPro01.models.Dev;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DevRepository extends JpaRepository<Dev, Long> {
    Optional<Dev> findByUserId(Long userId);
    Optional<Dev> findByUser_Id(Long userId);
}
