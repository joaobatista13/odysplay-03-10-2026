package com.aluno.projetoPro01.controllers;

import com.aluno.projetoPro01.models.Comunidade;
import com.aluno.projetoPro01.models.Noticia;
import com.aluno.projetoPro01.models.User;
import com.aluno.projetoPro01.services.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping({"/user", "/users"})
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<User> findById(@PathVariable Long id) {
        User obj = this.userService.findById(id);
        return ResponseEntity.ok().body(obj);
    }

    @GetMapping
    public ResponseEntity<List<User>> findAll() {
        List<User> list = this.userService.findAll();
        return ResponseEntity.ok().body(list);
    }

    @PostMapping
    public ResponseEntity<User> create(@Valid @RequestBody User obj) {
        User created = this.userService.create(obj);
        URI uri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/user/{id}").buildAndExpand(created.getId()).toUri();
        return ResponseEntity.created(uri).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody User obj, @PathVariable Long id) {
        obj.setId(id);
        this.userService.update(obj);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.userService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/noticias")
    public ResponseEntity<List<Noticia>> findNoticiasByUserId(@PathVariable Long id) {
        List<Noticia> list = this.userService.findNoticiasByUserId(id);
        return ResponseEntity.ok().body(list);
    }

    @GetMapping("/{id}/comunidades")
    public ResponseEntity<List<Comunidade>> findComunidadesByUserId(@PathVariable Long id) {
        List<Comunidade> list = this.userService.findComunidadesByUserId(id);
        return ResponseEntity.ok().body(list);
    }
}
