package com.aluno.projetoPro01.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "dev")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Dev {

    public interface CreateDev {}
    public interface UpdateDev {}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "id")
    private Long id;

    @OneToOne
    @JoinColumn(name = "idUsuario", nullable = false, unique = true)
    @JsonIgnoreProperties({"dev", "empresa", "noticias", "comunidades", "password"})
    private User user;

    @Column(name = "especialidade", length = 50, nullable = false)
    @NotBlank(message = "O campo 'especialidade' é obrigatório")
    private String especialidade;

    @Column(name = "dataNascimento")
    private LocalDate dataNascimento;

    @Column(name = "status", length = 50, nullable = false)
    private String status = "DISPONIVEL";

    @Column(name = "githubUrl", length = 255)
    private String githubUrl;

    @Column(name = "biografia", length = 255)
    private String biografia;

    @OneToMany(mappedBy = "dev")
    @JsonIgnore
    private List<Game> games = new ArrayList<>();

    @JsonProperty("idUsuario")
    public Long getIdUsuario() {
        return user != null ? user.getId() : null;
    }

    @JsonProperty("idUsuario")
    public void setIdUsuario(Long idUsuario) {
        if (idUsuario != null) {
            this.user = new User();
            this.user.setId(idUsuario);
        }
    }
}
