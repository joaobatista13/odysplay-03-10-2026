package com.aluno.projetoPro01.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "noticia")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Noticia {

    public interface CreateNoticia {}
    public interface UpdateNoticia {}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "idUsuario", nullable = false)
    @JsonIgnoreProperties({"dev", "empresa", "noticias", "comunidades", "password"})
    private User user;

    @Column(name = "titulo", length = 100, nullable = false)
    @NotBlank(message = "O campo 'titulo' é obrigatório")
    private String titulo;

    @Column(name = "autor", length = 100, nullable = false)
    @NotBlank(message = "O campo 'autor' é obrigatório")
    private String autor;

    @Column(name = "conteudo", columnDefinition = "TEXT", nullable = false)
    @NotBlank(message = "O campo 'conteudo' é obrigatório")
    private String conteudo;

    @Column(name = "dataPublicacao", nullable = false)
    private LocalDateTime dataPublicacao;

    @Column(name = "categoria", length = 50, nullable = false)
    @NotBlank(message = "O campo 'categoria' é obrigatório")
    private String categoria;

    @JsonProperty("idUsuario")
    public Long getIdUsuario() {
        return user != null ? user.getId() : null;
    }

    @JsonProperty("idUsuario")
    public void setIdUsuario(Long idUsuario) {
        if (idUsuario != null) {
            this.user = new User();
            this.user.setId(idUsuario);
        }
    }
}
