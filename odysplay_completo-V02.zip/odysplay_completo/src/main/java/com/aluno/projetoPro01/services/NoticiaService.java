package com.aluno.projetoPro01.services;

import com.aluno.projetoPro01.models.Noticia;
import com.aluno.projetoPro01.models.User;
import com.aluno.projetoPro01.repositories.NoticiaRepository;
import com.aluno.projetoPro01.repositories.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NoticiaService {

    @Autowired
    private NoticiaRepository noticiaRepository;

    @Autowired
    private UserRepository userRepository;

    public Noticia findById(Long id) {
        return this.noticiaRepository.findById(id).orElseThrow(() ->
                new EntityNotFoundException("Notícia não encontrada com ID: " + id));
    }

    public List<Noticia> findAll() {
        return this.noticiaRepository.findAll();
    }

    @Transactional
    public Noticia create(Noticia obj) {
        obj.setId(null);
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            obj.setUser(user);
        }
        if (obj.getDataPublicacao() == null) {
            obj.setDataPublicacao(LocalDateTime.now());
        }
        return this.noticiaRepository.save(obj);
    }

    @Transactional
    public Noticia update(Noticia obj) {
        if (obj.getId() == null) {
            throw new EntityNotFoundException("Notícia não encontrada: ID não fornecido");
        }
        Noticia existing = findById(obj.getId());
        if (obj.getTitulo() != null) {
            existing.setTitulo(obj.getTitulo());
        }
        if (obj.getAutor() != null) {
            existing.setAutor(obj.getAutor());
        }
        if (obj.getConteudo() != null) {
            existing.setConteudo(obj.getConteudo());
        }
        if (obj.getDataPublicacao() != null) {
            existing.setDataPublicacao(obj.getDataPublicacao());
        }
        if (obj.getCategoria() != null) {
            existing.setCategoria(obj.getCategoria());
        }
        if (obj.getIdUsuario() != null) {
            User user = this.userRepository.findById(obj.getIdUsuario()).orElseThrow(() ->
                    new EntityNotFoundException("Usuário não encontrado com ID: " + obj.getIdUsuario()));
            existing.setUser(user);
        }
        return this.noticiaRepository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        Noticia noticia = findById(id);
        this.noticiaRepository.delete(noticia);
    }
}
