package com.aluno.projetoPro01.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "empresa")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Empresa {

    public interface CreateEmpresa {}
    public interface UpdateEmpresa {}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "id")
    private Long id;

    @OneToOne
    @JoinColumn(name = "idUsuario", nullable = false, unique = true)
    @JsonIgnoreProperties({"dev", "empresa", "noticias", "comunidades", "password"})
    private User user;

    @Column(name = "nomeEmpresa", length = 100, nullable = false)
    @NotBlank(message = "O campo 'nomeEmpresa' é obrigatório")
    private String nomeEmpresa;

    @Column(name = "descricao", columnDefinition = "TEXT")
    private String descricao;

    @Column(name = "cnpj", length = 18)
    private String cnpj;

    @Column(name = "websiteUrl", length = 255)
    private String websiteUrl;

    @Column(name = "setor", length = 50)
    private String setor;

    @OneToMany(mappedBy = "empresa")
    @JsonIgnore
    private List<Game> games = new ArrayList<>();

    @JsonProperty("idUsuario")
    public Long getIdUsuario() {
        return user != null ? user.getId() : null;
    }

    @JsonProperty("idUsuario")
    public void setIdUsuario(Long idUsuario) {
        if (idUsuario != null) {
            this.user = new User();
            this.user.setId(idUsuario);
        }
    }
}
