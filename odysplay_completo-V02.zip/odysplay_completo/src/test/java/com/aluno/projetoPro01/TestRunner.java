package com.aluno.projetoPro01;

import org.mockito.MockitoAnnotations;

public class TestRunner {
    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("EXECUTANDO TESTES DO GLOBAL EXCEPTION HANDLER...");
        System.out.println("=================================================");

        GlobalExceptionHandlerTest test = new GlobalExceptionHandlerTest();

        int passed = 0;
        int failed = 0;

        try {
            System.out.println("\n--- [TESTE 1] GET /user/1 (200 OK) ---");
            AutoCloseable closeable = MockitoAnnotations.openMocks(test);
            test.setup();
            test.testGetSuccess();
            closeable.close();
            System.out.println(">> TESTE 1 PASSOU COM SUCESSO!");
            passed++;
        } catch (Throwable t) {
            System.err.println(">> TESTE 1 FALHOU: " + t.getMessage());
            t.printStackTrace();
            failed++;
        }

        try {
            System.out.println("\n--- [TESTE 2] GET /user/9999 (404 EntityNotFoundException) ---");
            AutoCloseable closeable = MockitoAnnotations.openMocks(test);
            test.setup();
            test.testGetNotFound();
            closeable.close();
            System.out.println(">> TESTE 2 PASSOU COM SUCESSO!");
            passed++;
        } catch (Throwable t) {
            System.err.println(">> TESTE 2 FALHOU: " + t.getMessage());
            t.printStackTrace();
            failed++;
        }

        try {
            System.out.println("\n--- [TESTE 3] POST /user com dado inválido (400 MethodArgumentNotValidException) ---");
            AutoCloseable closeable = MockitoAnnotations.openMocks(test);
            test.setup();
            test.testValidationFailure();
            closeable.close();
            System.out.println(">> TESTE 3 PASSOU COM SUCESSO!");
            passed++;
        } catch (Throwable t) {
            System.err.println(">> TESTE 3 FALHOU: " + t.getMessage());
            t.printStackTrace();
            failed++;
        }

        try {
            System.out.println("\n--- [TESTE 4] Simulação de erro interno (500 Internal Server Error) ---");
            AutoCloseable closeable = MockitoAnnotations.openMocks(test);
            test.setup();
            test.testGenericException();
            closeable.close();
            System.out.println(">> TESTE 4 PASSOU COM SUCESSO!");
            passed++;
        } catch (Throwable t) {
            System.err.println(">> TESTE 4 FALHOU: " + t.getMessage());
            t.printStackTrace();
            failed++;
        }

        System.out.println("\n=================================================");
        System.out.println("RESULTADO DOS TESTES: " + passed + " PASSARAM, " + failed + " FALHARAM.");
        System.out.println("=================================================");

        if (failed > 0) {
            System.exit(1);
        }
    }
}
