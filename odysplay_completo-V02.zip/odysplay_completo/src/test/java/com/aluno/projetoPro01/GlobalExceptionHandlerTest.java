package com.aluno.projetoPro01;

import com.aluno.projetoPro01.controllers.UserController;
import com.aluno.projetoPro01.exceptions.GlobalExceptionHandler;
import com.aluno.projetoPro01.models.User;
import com.aluno.projetoPro01.services.UserService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class GlobalExceptionHandlerTest {

    private MockMvc mockMvc;

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(userController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    @DisplayName("1. Teste de Sucesso: GET /user/1 -> 200 OK com JSON do recurso")
    public void testGetSuccess() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setNome("Caio");
        user.setUsername("caio_gamer");
        user.setEmail("caio@email.com");
        user.setPassword("12345678");
        user.setBiografia("Amo jogos indie");

        when(userService.findById(1L)).thenReturn(user);

        mockMvc.perform(get("/user/1")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nome").value("Caio"))
                .andExpect(jsonPath("$.username").value("caio_gamer"))
                .andExpect(jsonPath("$.email").value("caio@email.com"));
    }

    @Test
    @DisplayName("2. Teste de EntityNotFoundException: GET /user/9999 -> 404 Not Found com JSON padronizado")
    public void testGetNotFound() throws Exception {
        when(userService.findById(9999L)).thenThrow(new EntityNotFoundException("Usuário não encontrado com ID: 9999"));

        mockMvc.perform(get("/user/9999")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.message").value("Usuário não encontrado com ID: 9999"))
                .andExpect(jsonPath("$.timestamp").value(notNullValue()));
    }

    @Test
    @DisplayName("3. Teste de Validação: POST /user com campo obrigatório vazio -> 400 Bad Request com mensagem detalhada")
    public void testValidationFailure() throws Exception {
        String invalidJson = "{\"nome\": \"\", \"username\": \"caio_gamer\", \"email\": \"caio@email.com\", \"password\": \"123\"}";

        mockMvc.perform(post("/user")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(invalidJson))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.message", containsString("nome")))
                .andExpect(jsonPath("$.timestamp").value(notNullValue()));
    }

    @Test
    @DisplayName("4. Teste de Erro Genérico: Cenário de erro inesperado -> 500 com JSON padronizado")
    public void testGenericException() throws Exception {
        when(userService.findById(500L)).thenThrow(new RuntimeException("Falha inesperada no banco de dados"));

        mockMvc.perform(get("/user/500")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.status").value(500))
                .andExpect(jsonPath("$.message", containsString("Falha inesperada")))
                .andExpect(jsonPath("$.timestamp").value(notNullValue()));
    }
}
